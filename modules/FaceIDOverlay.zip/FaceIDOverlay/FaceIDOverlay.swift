import Cocoa
import QuartzCore
import Foundation

class FaceIDWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

class FaceIDOverlayView: NSView {

    override var isFlipped: Bool { true }

    enum State { case expanding, scanning }
    var state: State = .expanding

    let notchInfo = NotchDetector.detect()

    // MARK: Layers
    let islandLayer = CAShapeLayer()
    let contentLayer = CALayer()

    let glowLayer = CALayer()
    let outerRing = CAShapeLayer()
    let faceLayer = CAShapeLayer()

    // HARD CLIP
    let circleClipLayer = CALayer()

    // Animation
    var displayLink: CVDisplayLink?
    var startTime: CFTimeInterval = 0

    // Geometry
    var w: CGFloat = 0
    var h: CGFloat = 0
    var r: CGFloat = 0

    let targetW: CGFloat = 180
    let targetH: CGFloat = 210
    let r0: CGFloat = 18
    let r1: CGFloat = 42

    let black = NSColor.black.cgColor
    let blue = NSColor.systemBlue.cgColor
    let blueSoft = NSColor.systemBlue.withAlphaComponent(0.35).cgColor

    override init(frame: NSRect) {
        super.init(frame: frame)
        wantsLayer = true
        layer?.backgroundColor = NSColor.clear.cgColor
        setup()
        start()
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: Setup

    func setup() {

        islandLayer.fillColor = black
        islandLayer.shadowOpacity = 0.35
        islandLayer.shadowRadius = 22
        islandLayer.shadowOffset = CGSize(width: 0, height: -4)
        layer?.addSublayer(islandLayer)

        layer?.addSublayer(contentLayer)

        // Perspective
        var p = CATransform3DIdentity
        p.m34 = -1 / 700
        contentLayer.sublayerTransform = p

        glowLayer.shadowColor = blue
        glowLayer.shadowOpacity = 1
        glowLayer.shadowRadius = 32
        glowLayer.compositingFilter = "plusL"
        contentLayer.addSublayer(glowLayer)

        outerRing.strokeColor = blue
        outerRing.fillColor = NSColor.clear.cgColor
        outerRing.lineWidth = 4
        contentLayer.addSublayer(outerRing)

        faceLayer.strokeColor = blue
        faceLayer.fillColor = NSColor.clear.cgColor
        faceLayer.lineWidth = 3
        faceLayer.lineCap = .round
        faceLayer.lineJoin = .round
        contentLayer.addSublayer(faceLayer)

        circleClipLayer.masksToBounds = true
        contentLayer.addSublayer(circleClipLayer)

        w = notchInfo.width
        h = notchInfo.height
        r = r0

        updateIsland()
    }

    // MARK: Island

    func updateIsland() {

        let cx = notchInfo.centerX
        let top = notchInfo.centerY - notchInfo.height / 2

        islandLayer.path = NSBezierPath(
            roundedRect: CGRect(x: cx - w/2, y: top, width: w, height: h),
            xRadius: r,
            yRadius: r
        ).cgPath

        CATransaction.begin()
        CATransaction.setDisableActions(true)
        contentLayer.bounds = CGRect(x: 0, y: 0, width: w, height: h)
        contentLayer.position = CGPoint(x: cx, y: top + h/2)
        CATransaction.commit()
    }

    // MARK: Face + Circle

    func buildFace(size: CGFloat, centerY: CGFloat) {

        let cx = w / 2
        let frame = CGRect(x: cx - size/2, y: centerY - size/2, width: size, height: size)

        outerRing.path = NSBezierPath(ovalIn: frame).cgPath
        glowLayer.frame = frame

        circleClipLayer.frame = frame
        circleClipLayer.cornerRadius = size / 2

        let p = NSBezierPath()

        let eyeW = size * 0.06
        let eyeH = size * 0.12

        p.appendOval(in: CGRect(x: cx - size*0.18, y: centerY - eyeH/2, width: eyeW, height: eyeH))
        p.appendOval(in: CGRect(x: cx + size*0.12, y: centerY - eyeH/2, width: eyeW, height: eyeH))

        p.move(to: CGPoint(x: cx - size*0.22, y: centerY + size*0.12))
        p.curve(
            to: CGPoint(x: cx + size*0.22, y: centerY + size*0.12),
            controlPoint1: CGPoint(x: cx - size*0.12, y: centerY + size*0.30),
            controlPoint2: CGPoint(x: cx + size*0.12, y: centerY + size*0.30)
        )

        faceLayer.path = p.cgPath
    }

    // MARK: 🔥 DENSE MULTI-RING 3D ROLLING SYSTEM (12 RINGS)

    func buildGyroRings(radius: CGFloat) {

        circleClipLayer.sublayers?.removeAll()

        let ringCount = 12

        for i in 0..<ringCount {

            // Randomized but stable parameters
            let speed = 2.4 + Double(i % 5) * 0.6
            let phase = Double(i) * 0.8
            let inset = CGFloat(i % 4) * 2.0

            // Random-ish axis seed (deterministic)
            let ax = CGFloat((i * 37) % 10) / 10.0
            let ay = CGFloat((i * 53) % 10) / 10.0
            let az = CGFloat((i * 71) % 10) / 10.0

            // 1️⃣ Axis layer (orientation morphs)
            let axisLayer = CALayer()
            axisLayer.frame = circleClipLayer.bounds

            // 2️⃣ Rolling layer (constant roll)
            let rollLayer = CALayer()
            rollLayer.frame = axisLayer.bounds
            axisLayer.addSublayer(rollLayer)

            // 3️⃣ Ring shape
            let ring = CAShapeLayer()
            ring.path = NSBezierPath(
                ovalIn: rollLayer.bounds.insetBy(
                    dx: 4 + inset,
                    dy: 4 + inset
                )
            ).cgPath

            ring.strokeColor = blueSoft
            ring.fillColor = NSColor.clear.cgColor
            ring.lineWidth = 2.0
            ring.shadowColor = blue
            ring.shadowOpacity = 0.7
            ring.shadowRadius = 7

            rollLayer.addSublayer(ring)
            circleClipLayer.addSublayer(axisLayer)

            // 🔄 CONTINUOUS ROLL (local X axis)
            let roll = CABasicAnimation(keyPath: "transform.rotation.x")
            roll.fromValue = phase
            roll.toValue = phase + CGFloat.pi * 2
            roll.duration = speed
            roll.repeatCount = .infinity
            roll.timingFunction = CAMediaTimingFunction(name: .linear)
            rollLayer.add(roll, forKey: "roll")

            // 🔀 AXIS MORPHING (dynamic direction change)
            let axisAnim = CAKeyframeAnimation(keyPath: "transform")
            axisAnim.values = [
                CATransform3DRotate(CATransform3DIdentity, .pi/3, 1, 0, 0),
                CATransform3DRotate(CATransform3DIdentity, .pi/3, 0, 1, 0),
                CATransform3DRotate(CATransform3DIdentity, .pi/3, 1, 1, 0),
                CATransform3DRotate(CATransform3DIdentity, .pi/3, ax, ay, az),
                CATransform3DRotate(CATransform3DIdentity, .pi/3, 1, 0, 0)
            ]
            axisAnim.keyTimes = [0, 0.25, 0.5, 0.75, 1]
            axisAnim.duration = speed * 2.6
            axisAnim.repeatCount = .infinity
            axisAnim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)

            axisLayer.add(axisAnim, forKey: "axisMorph")
        }
    }



    // MARK: Loop

    func start() {
        startTime = CACurrentMediaTime()
        CVDisplayLinkCreateWithActiveCGDisplays(&displayLink)
        CVDisplayLinkSetOutputCallback(displayLink!, { _,_,_,_,_,ctx in
            let v = Unmanaged<FaceIDOverlayView>.fromOpaque(ctx!).takeUnretainedValue()
            DispatchQueue.main.async { v.tick() }
            return kCVReturnSuccess
        }, Unmanaged.passUnretained(self).toOpaque())
        CVDisplayLinkStart(displayLink!)
    }

    func tick() {
        let t = CACurrentMediaTime() - startTime
        if state == .expanding {
            let p = min(t / 0.55, 1)
            let e = p*p*(3-2*p)
            w = notchInfo.width + (targetW - notchInfo.width)*e
            h = notchInfo.height + (targetH - notchInfo.height)*e
            r = r0 + (r1 - r0)*e
            updateIsland()
            if p == 1 {
                state = .scanning
                startScan()
            }
        }
    }

    func startScan() {
        let size: CGFloat = 96
        let centerY = notchInfo.height + (h - notchInfo.height)/2
        buildFace(size: size, centerY: centerY)
        buildGyroRings(radius: size/2)

        let glowPulse = CABasicAnimation(keyPath: "shadowRadius")
        glowPulse.fromValue = 24
        glowPulse.toValue = 42
        glowPulse.duration = 1.1
        glowPulse.autoreverses = true
        glowPulse.repeatCount = .infinity
        glowLayer.add(glowPulse, forKey: "pulse")
    }
}

// MARK: App

class AppDelegate: NSObject, NSApplicationDelegate {
    var window: FaceIDWindow!
    func applicationDidFinishLaunching(_ n: Notification) {
        let s = NSScreen.main!
        window = FaceIDWindow(
            contentRect: s.frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        window.level = .statusBar
        window.isOpaque = false
        window.backgroundColor = .clear
        window.ignoresMouseEvents = true
        window.contentView = FaceIDOverlayView(frame: s.frame)
        window.makeKeyAndOrderFront(nil)
    }
}

@main
struct FaceIDApp {
    static func main() {
        let app = NSApplication.shared
        let d = AppDelegate()
        app.delegate = d
        app.setActivationPolicy(.accessory)
        app.run()
    }
}

