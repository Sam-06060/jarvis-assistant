import Cocoa
import QuartzCore
import Foundation

class FaceIDWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

// MARK: - Spring Physics Engine
struct Spring {
    var value: CGFloat
    var target: CGFloat
    var velocity: CGFloat = 0
    
    // Physics Configuration
    let tension: CGFloat = 180
    let friction: CGFloat = 16
    
    mutating func update(dt: CGFloat) -> Bool {
        let displacement = value - target
        let force = -tension * displacement - friction * velocity
        velocity += force * dt
        value += velocity * dt
        return abs(displacement) < 0.1 && abs(velocity) < 0.1
    }
}

class FaceIDOverlayView: NSView {

    override var isFlipped: Bool { true }

    enum State { case expanding, scanning, success }
    var state: State = .expanding

    let notchInfo = NotchDetector.detect()

    // MARK: Layers
    let islandLayer = CAShapeLayer()
    let contentLayer = CALayer()
    let glowLayer = CALayer()
    
    let outerRing = CAShapeLayer()      // Brackets -> Hidden on success
    let featuresLayer = CAShapeLayer()  // Face Glyph
    let circleClipLayer = CALayer()     // Holds the 2 Ring Clusters

    // Animation / Physics
    var displayLink: CVDisplayLink?
    var lastTime: CFTimeInterval = 0
    
    lazy var wSpring = Spring(value: notchInfo.width, target: notchInfo.width + 60)
    lazy var hSpring = Spring(value: notchInfo.height, target: 220)
    lazy var rSpring = Spring(value: 16, target: 48)
    lazy var alphaSpring = Spring(value: 0, target: 1)

    // MARK: - COLORS (Neon Green)
    let black = NSColor.black.cgColor
    
    // Vibrant Neon Green
    let neonGreen = NSColor(displayP3Red: 0.0, green: 1.0, blue: 0.2, alpha: 1.0).cgColor
    
    // Constants
    let faceLineWidth: CGFloat = 3.8
    let heroRingWidth: CGFloat = 3.5
    let ghostRingWidth: CGFloat = 4.2
    
    override init(frame: NSRect) {
        super.init(frame: frame)
        wantsLayer = true
        layer?.backgroundColor = NSColor.clear.cgColor
        setup()
        start()
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: Setup

    func setup() {
        islandLayer.fillColor = black
        islandLayer.shadowOpacity = 0
        islandLayer.shadowRadius = 30
        islandLayer.shadowOffset = CGSize(width: 0, height: 4)
        layer?.addSublayer(islandLayer)

        layer?.addSublayer(contentLayer)
        
        var p = CATransform3DIdentity
        p.m34 = -1 / 700
        contentLayer.sublayerTransform = p

        // Green Glow
        glowLayer.shadowColor = neonGreen
        glowLayer.shadowOpacity = 1
        glowLayer.shadowRadius = 36
        glowLayer.compositingFilter = "plusL"
        contentLayer.addSublayer(glowLayer)

        // Green Outer Ring (Brackets)
        outerRing.strokeColor = neonGreen
        outerRing.fillColor = NSColor.clear.cgColor
        outerRing.lineWidth = faceLineWidth
        outerRing.lineCap = .round
        outerRing.lineJoin = .round
        contentLayer.addSublayer(outerRing)

        // Green Features
        featuresLayer.strokeColor = neonGreen
        featuresLayer.fillColor = NSColor.clear.cgColor
        featuresLayer.lineWidth = faceLineWidth
        featuresLayer.lineCap = .round
        featuresLayer.lineJoin = .round
        contentLayer.addSublayer(featuresLayer)

        circleClipLayer.masksToBounds = true
        contentLayer.addSublayer(circleClipLayer)

        contentLayer.opacity = 0
        updateIslandGeometry()
    }

    // MARK: Physics Loop

    func start() {
        lastTime = CACurrentMediaTime()
        CVDisplayLinkCreateWithActiveCGDisplays(&displayLink)
        CVDisplayLinkSetOutputCallback(displayLink!, { _,_,_,_,_,ctx in
            let v = Unmanaged<FaceIDOverlayView>.fromOpaque(ctx!).takeUnretainedValue()
            DispatchQueue.main.async { v.tick() }
            return kCVReturnSuccess
        }, Unmanaged.passUnretained(self).toOpaque())
        CVDisplayLinkStart(displayLink!)
    }

    func tick() {
        let now = CACurrentMediaTime()
        let dt = CGFloat(min(now - lastTime, 0.05))
        lastTime = now

        if state == .expanding {
            let wDone = wSpring.update(dt: dt)
            let hDone = hSpring.update(dt: dt)
            let rDone = rSpring.update(dt: dt)
            let aDone = alphaSpring.update(dt: dt)
            
            updateIslandGeometry()
            
            islandLayer.shadowOpacity = Float(alphaSpring.value) * 0.5
            contentLayer.opacity = Float(alphaSpring.value)

            if wDone && hDone && rDone && aDone {
                state = .scanning
                startScan()
            }
        }
    }

    // MARK: Geometry Update

    func updateIslandGeometry() {
        let w = wSpring.value
        let h = hSpring.value
        let r = rSpring.value
        
        let cx = notchInfo.centerX
        let top: CGFloat = 0

        islandLayer.path = NSBezierPath(
            roundedRect: CGRect(
                x: cx - w / 2,
                y: top,
                width: w,
                height: h
            ),
            xRadius: r,
            yRadius: r
        ).cgPath

        CATransaction.begin()
        CATransaction.setDisableActions(true)
        contentLayer.bounds = CGRect(x: 0, y: 0, width: w, height: h)
        contentLayer.position = CGPoint(x: cx, y: h / 2)
        CATransaction.commit()
    }

    // MARK: Scanning Logic (Breathing Face)

    func startScan() {
        let size: CGFloat = 84
        let centerY = hSpring.value / 2
        
        buildFace(size: size, centerY: centerY)

        let scaleAnim = CABasicAnimation(keyPath: "transform.scale")
        scaleAnim.fromValue = 0.96
        scaleAnim.toValue = 1.04
        scaleAnim.duration = 1.3
        scaleAnim.autoreverses = true
        scaleAnim.repeatCount = .infinity
        scaleAnim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        contentLayer.add(scaleAnim, forKey: "breathingScale")
        
        let glowAnim = CABasicAnimation(keyPath: "shadowRadius")
        glowAnim.fromValue = 20
        glowAnim.toValue = 50
        glowAnim.duration = 1.3
        glowAnim.autoreverses = true
        glowAnim.repeatCount = .infinity
        glowAnim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        glowLayer.add(glowAnim, forKey: "breathingGlow")
        
        print("Ready. Type 'success' in terminal to unlock.")
    }

    func buildFace(size: CGFloat, centerY: CGFloat) {
        let cx = wSpring.value / 2
        featuresLayer.frame = contentLayer.bounds
        
        let frame = CGRect(
            x: cx - size / 2,
            y: centerY - size / 2,
            width: size,
            height: size
        )
        
        // 1. OUTER RING (Brackets)
        let bracketPath = NSBezierPath()
        let gap = size * 0.25
        let cornerR = size * 0.28
        let minX = frame.minX, maxX = frame.maxX
        let minY = frame.minY, maxY = frame.maxY
        
        // Top Left
        bracketPath.move(to: CGPoint(x: minX, y: frame.midY - gap))
        bracketPath.appendArc(from: CGPoint(x: minX, y: minY), to: CGPoint(x: frame.midX, y: minY), radius: cornerR)
        bracketPath.line(to: CGPoint(x: frame.midX - gap, y: minY))
        
        // Top Right
        bracketPath.move(to: CGPoint(x: frame.midX + gap, y: minY))
        bracketPath.appendArc(from: CGPoint(x: maxX, y: minY), to: CGPoint(x: maxX, y: frame.midY), radius: cornerR)
        bracketPath.line(to: CGPoint(x: maxX, y: frame.midY - gap))
        
        // Bottom Right
        bracketPath.move(to: CGPoint(x: maxX, y: frame.midY + gap))
        bracketPath.appendArc(from: CGPoint(x: maxX, y: maxY), to: CGPoint(x: frame.midX, y: maxY), radius: cornerR)
        bracketPath.line(to: CGPoint(x: frame.midX + gap, y: maxY))
        
        // Bottom Left
        bracketPath.move(to: CGPoint(x: frame.midX - gap, y: maxY))
        bracketPath.appendArc(from: CGPoint(x: minX, y: maxY), to: CGPoint(x: minX, y: frame.midY), radius: cornerR)
        bracketPath.line(to: CGPoint(x: minX, y: frame.midY + gap))
        
        outerRing.path = bracketPath.cgPath
        glowLayer.frame = frame
        circleClipLayer.frame = frame
        circleClipLayer.cornerRadius = cornerR

        // 2. FACE FEATURES
        let p = NSBezierPath()
        let eyeW = size * 0.105
        let eyeH = size * 0.16
        let eyeSpacing = size * 0.19
        
        let leftEyeRect = CGRect(x: cx - eyeSpacing - eyeW/2, y: centerY - eyeH * 0.55, width: eyeW, height: eyeH)
        let rightEyeRect = CGRect(x: cx + eyeSpacing - eyeW/2, y: centerY - eyeH * 0.55, width: eyeW, height: eyeH)
        
        p.append(NSBezierPath(roundedRect: leftEyeRect, xRadius: eyeW/2, yRadius: eyeW/2))
        p.append(NSBezierPath(roundedRect: rightEyeRect, xRadius: eyeW/2, yRadius: eyeW/2))

        let noseTop = CGPoint(x: cx, y: centerY - size * 0.08)
        let noseCorner = CGPoint(x: cx, y: centerY + size * 0.12)
        let noseEnd = CGPoint(x: cx - size * 0.11, y: centerY + size * 0.12)
        
        p.move(to: noseTop)
        p.line(to: noseCorner)
        p.curve(
            to: noseEnd,
            controlPoint1: CGPoint(x: cx, y: centerY + size * 0.17),
            controlPoint2: CGPoint(x: cx - size * 0.08, y: centerY + size * 0.17)
        )
        
        let mouthY = centerY + size * 0.24
        let mouthW = size * 0.21
        p.move(to: CGPoint(x: cx - mouthW, y: mouthY))
        p.curve(
            to: CGPoint(x: cx + mouthW, y: mouthY),
            controlPoint1: CGPoint(x: cx - mouthW * 0.5, y: mouthY + size * 0.14),
            controlPoint2: CGPoint(x: cx + mouthW * 0.5, y: mouthY + size * 0.14)
        )
        
        featuresLayer.path = p.cgPath
        startIdleAnimation()
    }
    
    func startIdleAnimation() {
        let lookX = CAKeyframeAnimation(keyPath: "transform.translation.x")
        lookX.values = [0, 2, -2, 0]
        lookX.keyTimes = [0, 0.3, 0.7, 1]
        lookX.duration = 5.0
        lookX.repeatCount = .infinity
        lookX.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        
        let lookY = CAKeyframeAnimation(keyPath: "transform.translation.y")
        lookY.values = [0, -1.5, 1, 0]
        lookY.keyTimes = [0, 0.2, 0.8, 1]
        lookY.duration = 6.5
        lookY.repeatCount = .infinity
        lookY.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        
        featuresLayer.add(lookX, forKey: "lookX")
        featuresLayer.add(lookY, forKey: "lookY")
    }

    // MARK: TRIGGER (Pop + Activate Double Rings)

    func triggerSuccessAnimation() {
        guard state == .scanning else { return }
        state = .success

        let size: CGFloat = 84
        let centerY = hSpring.value / 2
        let cx = wSpring.value / 2
        let frame = CGRect(x: cx - size / 2, y: centerY - size / 2, width: size, height: size)

        contentLayer.removeAnimation(forKey: "breathingScale")
        glowLayer.removeAnimation(forKey: "breathingGlow")

        // 1. POP OUT (Shrink)
        let popOut = CABasicAnimation(keyPath: "transform.scale")
        popOut.fromValue = 1.0
        popOut.toValue = 0.01
        popOut.duration = 0.2
        popOut.timingFunction = CAMediaTimingFunction(controlPoints: 0.3, 0.0, 1.0, 1.0)
        popOut.fillMode = .forwards
        popOut.isRemovedOnCompletion = false
        contentLayer.add(popOut, forKey: "popOut")
        
        // 2. THE SWAP
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            
            self.featuresLayer.opacity = 0
            self.outerRing.opacity = 0 // Hide bracket layer, we use ring clusters now
            self.circleClipLayer.cornerRadius = size / 2
            
            // SPAWN 2 CLUSTERS (High Speed)
            self.spawnRingCluster(radius: size / 2, clockwise: true)
            self.spawnRingCluster(radius: size / 2, clockwise: false)
            
            // POP IN (Spring)
            let spring = CASpringAnimation(keyPath: "transform.scale")
            spring.fromValue = 0.01
            spring.toValue = 1.0
            spring.mass = 0.6
            spring.stiffness = 240
            spring.damping = 14
            spring.initialVelocity = 10
            spring.duration = spring.settlingDuration
            spring.fillMode = .forwards
            spring.isRemovedOnCompletion = false
            
            self.contentLayer.add(spring, forKey: "popIn")
        }
    }
    
    // MARK: - THE "AXIS SHIFT" ANIMATION LOGIC (TURBO SPEED)
    func animateAxisShift(layer: CALayer, clockwise: Bool) {
        // ⬅️ HIGH SPEED CONFIG
        let tumbleDuration: Double = 3.5 // Fast Tumble (Was 5.0)
        let spinDuration: Double = 1.5   // Fast Spin (Was 2.0)
        
        // Spin
        let spin = CABasicAnimation(keyPath: "transform.rotation")
        spin.fromValue = 0
        spin.toValue = clockwise ? CGFloat.pi * 2 : -CGFloat.pi * 2
        spin.duration = spinDuration
        spin.repeatCount = .infinity
        spin.timingFunction = CAMediaTimingFunction(name: .linear)
        
        // Axis Morph
        let xRot = CAKeyframeAnimation(keyPath: "transform.rotation.x")
        xRot.values = [0, clockwise ? CGFloat.pi : -CGFloat.pi, 0]
        xRot.keyTimes = [0, 0.5, 1]
        xRot.duration = tumbleDuration
        xRot.repeatCount = .infinity
        xRot.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        
        let yRot = CAKeyframeAnimation(keyPath: "transform.rotation.y")
        yRot.values = [0, clockwise ? CGFloat.pi * 2 : -CGFloat.pi * 2, clockwise ? CGFloat.pi * 4 : -CGFloat.pi * 4]
        yRot.duration = tumbleDuration * 0.8
        yRot.repeatCount = .infinity
        yRot.timingFunction = CAMediaTimingFunction(name: .linear)
        
        layer.add(xRot, forKey: "gymbalX")
        layer.add(yRot, forKey: "gymbalY")
        layer.add(spin, forKey: "spin")
    }

    // MARK: Ring Cluster Spawner (DENSE TRAIL)

    func spawnRingCluster(radius: CGFloat, clockwise: Bool) {
        
        let count = 14

        for i in 0..<count {
            let isHero = i == 0
            
            let axisLayer = CALayer()
            axisLayer.frame = circleClipLayer.bounds

            let ring = CAShapeLayer()
            ring.path = NSBezierPath(ovalIn: axisLayer.bounds.insetBy(dx: 2, dy: 2)).cgPath

            if isHero {
                ring.lineWidth = heroRingWidth
                ring.opacity = 1.0
            } else {
                ring.lineWidth = ghostRingWidth // Thicker Ghost
                // Long Fade
                let progress = CGFloat(i) / CGFloat(count)
                let fade = 1.0 - progress
                ring.opacity = Float(0.14 * fade)
            }
            
            ring.strokeColor = neonGreen
            ring.fillColor = NSColor.clear.cgColor
            ring.shadowColor = neonGreen
            ring.shadowOpacity = isHero ? 0.8 : 0
            ring.shadowRadius = 8

            axisLayer.addSublayer(ring)
            circleClipLayer.addSublayer(axisLayer)
            
            // ⬅️ REDUCED DELAY for High Speed Density (0.025s)
            let delay = Double(i) * 0.020
            
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                self.animateAxisShift(layer: axisLayer, clockwise: clockwise)
            }
        }
    }
}

// MARK: App

class AppDelegate: NSObject, NSApplicationDelegate {
    var window: FaceIDWindow!
    var view: FaceIDOverlayView!

    func applicationDidFinishLaunching(_ n: Notification) {
        let s = NSScreen.main!
        window = FaceIDWindow(
            contentRect: s.frame,
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        window.level = .statusBar
        window.isOpaque = false
        window.backgroundColor = .clear
        window.ignoresMouseEvents = true
        
        view = FaceIDOverlayView(frame: s.frame)
        window.contentView = view
        window.makeKeyAndOrderFront(nil)
        
        setupTerminalListener()
    }
    
    func setupTerminalListener() {
        DispatchQueue.global(qos: .background).async {
            print("--- Listening for Input ---")
            if let _ = readLine() {
                DispatchQueue.main.async {
                    print("Unlocking...")
                    self.view.triggerSuccessAnimation()
                }
            }
        }
    }
}

@main
struct FaceIDApp {
    static func main() {
        let app = NSApplication.shared
        let d = AppDelegate()
        app.delegate = d
        app.setActivationPolicy(.accessory)
        app.run()
    }
}
